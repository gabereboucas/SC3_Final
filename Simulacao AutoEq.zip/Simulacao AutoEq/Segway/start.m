clear;
start_config;
variables_set;
matrix_set;

