plot_voltage(tout, m_volt)
plot_psi(tout, m_psi)
plot_psi_d(tout, m_psi_d)
plot_theta_d(tout, m_theta_d)